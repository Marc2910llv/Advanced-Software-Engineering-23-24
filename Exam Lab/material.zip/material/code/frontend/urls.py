GATEWAY_URL = 'http://gateway:5000'
MATH_URL = 'http://math-service:5000'
STRING_URL = 'http://string-service:5000'