Some API examples:
http://localhost:5000/ping/google.it                #ping google.it
http://localhost:5000/log/count/math-service2:5000  #count logs for math-service2 in db 
http://localhost:5000/math/add?lst=[1,2,3,4]        #sum the content of a list
http://localhost:5000/math/secure_random?a=1&b=6    #returns a random number between 1 and 6